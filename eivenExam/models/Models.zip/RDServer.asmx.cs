﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Eiven.EXE.Web.Models
{
    /// <summary>
    /// Exam2020 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class RDServer : System.Web.Services.WebService
    {


        [WebMethod]
        public void SpyScreenArea(int x, int y, byte[] screen, string clientName)
        {
            try
            {
                string rootpath = Server.MapPath("RD") + "\\";

                string recordPath = rootpath + clientName + "\\" + y + "." + x + "\\";

                Directory.CreateDirectory(recordPath);

                string recordFilename = recordPath + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss.fff") + ".jpg";

                File.WriteAllBytes(recordFilename, screen);

                // Db.Execute("UPDATE Exam2020Stu SET ScreenNext = ScreenNow WHERE ID=" + uid);
                // Db.Execute("UPDATE Exam2020Stu SET ScreenNow  ='" + recordPath.Replace("'", "''") + "', LastUpdate=GetDate() WHERE ID=" + uid);

                string[] files = Directory.GetFiles(recordPath);
                Array.Sort(files);
                for (int i = 0; i < files.Length - 2; ++i)
                {
                    File.Delete(files[i]);
                }
            }
            catch (System.Exception ex)
            {
                //Log(uid, "保存客户端截屏错误：" + ex.Message);

            }
        }

        [WebMethod]
        public void SpyMouse(float x, float y, string clientName)
        {
            Application[clientName + "_Mouse"] = new PointF(x, y);
        }


    }
}
